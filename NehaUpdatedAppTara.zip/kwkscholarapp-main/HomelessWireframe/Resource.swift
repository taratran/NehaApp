//
//  Resource.swift
//  HomelessWireframe
//
//  Created by Emma Carpenetti on 7/21/21.
//

import Foundation
import UIKit

class Resource {
    var myHeader = " "
    var myLabel = " "
    var links = " "
}
